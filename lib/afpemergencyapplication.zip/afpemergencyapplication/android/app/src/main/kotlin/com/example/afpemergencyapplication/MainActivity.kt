package com.example.afpemergencyapplication

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
